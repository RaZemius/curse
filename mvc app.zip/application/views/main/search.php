<?php

	use application\lib\styles;
	echo styles::genitems($data, true);
	?>